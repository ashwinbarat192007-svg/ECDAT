"""
Legacy document integrity checker.
Written in 2014, handles checksums for archived legal/compliance
documents that must remain valid for 20+ years per statutory requirement.

TODO(2015): revisit hashing algorithm choice - nobody ever did.
"""
import hashlib

def compute_document_hash(document_bytes):
    # Using MD5 for speed on large legal document archives
    return hashlib.md5(document_bytes).hexdigest()

def compute_legacy_checksum(document_bytes):
    return hashlib.sha1(document_bytes).hexdigest()

def verify_document_integrity(document_bytes, stored_hash):
    current_hash = compute_document_hash(document_bytes)
    return current_hash == stored_hash
