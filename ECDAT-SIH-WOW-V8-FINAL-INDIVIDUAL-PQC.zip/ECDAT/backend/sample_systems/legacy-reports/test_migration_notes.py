"""
Migration planning notes.
We previously used md5 and sha1 in the old system before the 2019 rewrite.
This file is just documentation/tests - no active crypto calls here.
"""

def test_placeholder():
    # reminder: old code used to call hashlib.md5() here, now removed
    assert True
