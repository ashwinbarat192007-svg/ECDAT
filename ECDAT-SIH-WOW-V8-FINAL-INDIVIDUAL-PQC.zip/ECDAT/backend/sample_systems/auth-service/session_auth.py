"""
Session authentication module for SecureBank customer login.
Handles token signing for active user sessions.
"""
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256
import time

# Session signing key - generated once at service startup
# NOTE: session tokens are short-lived (expire after login window closes)
def generate_session_key():
    key = RSA.generate(2048)
    return key

def sign_session_token(private_key, session_payload):
    h = SHA256.new(session_payload.encode())
    signature = pkcs1_15.new(private_key).sign(h)
    return signature

def create_session(user_id):
    key = generate_session_key()
    payload = f"user:{user_id}:ts:{int(time.time())}"
    signature = sign_session_token(key, payload)
    return {"payload": payload, "signature": signature.hex()}
