"""
Internal Certificate Authority for inter-service TLS.
Issues certificates used for service-to-service authentication
across the entire SecureBank internal network. Root CA cert
was issued in 2016 and signs certs used to secure PII data stores
with a 25 year data protection commitment to customers.
"""
from Crypto.PublicKey import RSA

def generate_root_ca_key():
    # Original root CA - 1024 bit, issued before 2048 became standard
    return RSA.generate(1024)

def issue_service_cert(ca_key, service_name):
    cert = {
        "subject": service_name,
        "issuer": "SecureBank-Internal-Root-CA",
        "signature_algorithm": "sha1WithRSAEncryption",
        "key_size": 1024
    }
    return cert
