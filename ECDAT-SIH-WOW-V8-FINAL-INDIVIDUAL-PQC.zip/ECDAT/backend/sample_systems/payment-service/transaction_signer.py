"""
Transaction signing service for SecureBank payment gateway.
Every outbound transaction record is cryptographically signed
for non-repudiation and stored for regulatory audit (7 year retention).
"""
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import utils

# Transaction records must remain verifiable for 7 years per RBI retention policy
def generate_transaction_key():
    private_key = ec.generate_private_key(ec.SECP256R1())
    return private_key

def sign_transaction(private_key, transaction_bytes):
    signature = private_key.sign(
        transaction_bytes,
        ec.ECDSA(hashes.SHA256())
    )
    return signature

def verify_transaction(public_key, signature, transaction_bytes):
    try:
        public_key.verify(signature, transaction_bytes, ec.ECDSA(hashes.SHA256()))
        return True
    except Exception:
        return False
