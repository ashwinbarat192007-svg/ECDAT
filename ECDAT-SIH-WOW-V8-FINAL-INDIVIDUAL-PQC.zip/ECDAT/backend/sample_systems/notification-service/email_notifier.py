"""
Customer notification service. Sends transactional emails/SMS.
No cryptographic operations performed directly - relies on the
managed email provider's TLS transport (out of scope for this scan).
"""
import requests

def send_notification(user_email, message):
    response = requests.post(
        "https://notify.internal.securebank.example/send",
        json={"to": user_email, "body": message},
        timeout=5
    )
    return response.status_code == 200

def format_message(template, **kwargs):
    return template.format(**kwargs)
